import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class About extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(22, 69, 24, 48),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'About Apps',
                        style: GoogleFonts.getFont(
                          'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 25,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(13, 0, 6, 383),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFFFDDA0),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Container(
                        height: 332,
                        padding: EdgeInsets.fromLTRB(0.5, 12, 0, 0),
                        child: Text(
                          'Hallo Teman SIBI!',
                          style: GoogleFonts.getFont(
                            'Rammetto One',
                            fontWeight: FontWeight.w400,
                            fontSize: 24,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFF8B11B),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Container(
                        width: 87,
                        padding: EdgeInsets.fromLTRB(0, 7, 3.7, 4),
                        child: Text(
                          'HOME',
                          style: GoogleFonts.getFont(
                            'Poppins',
                            fontWeight: FontWeight.w600,
                            fontSize: 10,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 30,
              top: 126,
              child: SizedBox(
                height: 276,
                child: Text(
                  'Aplikasi MySIBI merupakan aplikasi berbasis Android yang dikembangkan agar dapat menerjemahkan bahasa isyarat kata SIBI secara realtime. Saat ini terdapat 25 isyarat yang dapat diterjemahkan yang digunakan untuk kalimat sapaan.  
            Dengan dikembangkannya aplikasi ini diharapkan dapat membantu teman tuli maupun masyarakat umum dalam berkomunikasi satu sama lain. ',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.getFont(
                    'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                    color: Color(0xFF000000),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}