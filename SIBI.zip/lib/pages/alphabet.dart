import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Alphabet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(22, 70, 23, 48),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 47),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(
                  'Alphabet ',
                  style: GoogleFonts.getFont(
                    'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 25,
                    color: Color(0xFF000000),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 312),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFFF8B11B),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Container(
                  width: 383,
                  height: 385,
                  padding: EdgeInsets.fromLTRB(14, 13, 13, 13),
                  child: Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage(
                          'assets/images/nxwz_1_im_1.png',
                        ),
                      ),
                    ),
                    child: Container(
                      width: 356,
                      height: 359,
                    ),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(6, 0, 6, 0),
              child: Align(
                alignment: Alignment.topRight,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFFF8B11B),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Container(
                    width: 87,
                    padding: EdgeInsets.fromLTRB(0, 7, 3.7, 4),
                    child: Text(
                      'HOME',
                      style: GoogleFonts.getFont(
                        'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 10,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}