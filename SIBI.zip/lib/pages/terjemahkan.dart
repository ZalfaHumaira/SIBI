import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Terjemahkan extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 70, 0, 48),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(22, 0, 22, 30),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Translate',
                        style: GoogleFonts.getFont(
                          'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 25,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 22),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFF8B11B),
                      ),
                      child: Container(
                        width: 428,
                        height: 429,
                        padding: EdgeInsets.fromLTRB(7, 8, 8, 8),
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                'assets/images/home_1.jpeg',
                              ),
                            ),
                          ),
                          child: Container(
                            width: 413,
                            height: 413,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(22, 0, 22, 21),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Result :',
                        style: GoogleFonts.getFont(
                          'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 25,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 1, 86),
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFFFFDDA0),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Container(
                          width: 323,
                          padding: EdgeInsets.fromLTRB(0, 24, 0, 56),
                          child: Text(
                            'Rumah',
                            style: GoogleFonts.getFont(
                              'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 25,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(29, 0, 29, 0),
                    child: Align(
                      alignment: Alignment.topRight,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFFF8B11B),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Container(
                          width: 87,
                          padding: EdgeInsets.fromLTRB(0, 7, 3.7, 4),
                          child: Text(
                            'HOME',
                            style: GoogleFonts.getFont(
                              'Poppins',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 12,
              bottom: 133,
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFFF8B11B),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Container(
                  width: 61,
                  height: 53,
                  padding: EdgeInsets.fromLTRB(10, 6, 11, 7),
                  child: Container(
                    width: 40,
                    height: 40,
                    child: SizedBox(
                      width: 40,
                      height: 40,
                      child: SvgPicture.asset(
                        'assets/vectors/group_x2.svg',
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              right: 73,
              bottom: 133,
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFFF8B11B),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Container(
                  width: 61,
                  height: 53,
                  padding: EdgeInsets.fromLTRB(12, 11, 11, 12),
                  child: SizedBox(
                    width: 38,
                    height: 30,
                    child: SvgPicture.asset(
                      'assets/vectors/vector_1_x2.svg',
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}